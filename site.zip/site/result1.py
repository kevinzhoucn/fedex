#coding: utf-8
import pymssql
import sys
import csv
script ="""
         select TRANSACTION_ID,ANNOUNCE_DATE,EXP_EFF_DATE,UNCONDITIONAL_DATE,replace(ACQTECH,',',' ') as ACQTECH,[ROLE],COMPANY_NAME,SUCCESSOR_FLAG,HEADQUARTER_COUNTRY,REGISTERATION_COUNTRY,CROSS_BORDER,OAID,RDCORGID,PRIMARYINSTRUMENTID,PRIMARYQUOTATIONID,RIC,ISIN,CUSIP,SEDOL,PUBLIC_PRIVATE,SUMMARY 
         from dbo.reincorp_upcomingevents
         order by exp_eff_date desc, unconditional_date, announce_date, TRANSACTION_ID, ROLE
         """

def get_connection():
    try:
        conn1 = pymssql.connect(host='10.35.16.207', user='read_only', password='read_only', database ='workbench')
        return conn1
    except:
        print 'Connection Failed.'
        return None
def runscript(script):
    conn = get_connection()linwterminator='\n'
    cursor = conn.cursor()
    try:
        cursor.execute(script)
        rows = cursor.fetchall() 
        csvfile = open('test.csv', 'w')
        writer = csv.writer(csvfile,linwterminator='\n',delimiter=';',quotechar='|', quoting=csv.QUOTE_MINIMAL)
        writer.writerow(['TRANSACTION ID','ANNOUNCE DATE','EXPECTED EFFECTIVE DATE','UNCONDITIONAL DATE','ACQUISITION TECHNIQUE','ROLE','COMPANY NAME','SUCCESSOR FLAG','HEADQUARTER COUNTRY','REGISTERATION COUNTRY','CROSS BORDER','OA ID','RDC ORGID','PRIMARY INSTRUMENT ID','PRIMARY QUOTATION ID','RIC','ISIN','CUSIP','SEDOL','PUBLIC OR PRIVATE','SUMMARY'])
        writer.writerows(rows)
        csvfile.close()
        conn.commit()
    except Exception, e:
        print str(e) 
    conn.close() 

runscript(script)







